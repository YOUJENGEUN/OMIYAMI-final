package com.omiyami.shop.user.mypage;

import com.omiyami.shop.product.ProductVO;
import com.omiyami.shop.user.UserVO;

public class MypageVO {

	private UserVO user;
	private ProductVO product;
	private UserCouponVO coupon;
}
